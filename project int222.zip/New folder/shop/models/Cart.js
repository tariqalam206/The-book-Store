const mongoose = require("mongoose");


const Cartschema =new mongoose.Schema({
    userId: {type: String, required:true},
    products: [
        {
            productId:{type:String,},
            qauntity:{
                type:Number,
                default:1,

            },   
        },
    ],
    
},
{timestamps:true}
);
module.exports =mongoose.model("Cart",Cartschema);